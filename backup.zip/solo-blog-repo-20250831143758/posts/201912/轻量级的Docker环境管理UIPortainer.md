title: 轻量级的Docker环境管理UI--Portainer
date: '2019-12-25 15:02:17'
updated: '2019-12-25 15:02:17'
tags: [docker]
permalink: /articles/2019/12/25/1577286137240.html
---
* Portainer 是一个轻量级的 docker 环境管理 UI，可以用来管理 docker 宿主机和 docker swarm 集群。他的轻量级，轻量到只要个不到 100M 的 docker 镜像容器就可以完整的提供服务。直接启动即可，异常方便。在 Docker 放出 Swarm 之后，借此也实现了集群管理功能。

## Portainer 主要功能：

1. 提供状态显示面板：显示主机或者 swarm 集群上有多少镜像，容器等
2. 应用模板快速部署：可以使用预存的模板或者自己定制的模板快速部署
3. 事件日志显示：对任何操作有记录，并且有页面可以显示审计日志
4. 容器控制台操作：查看容器，管理容器，查看容器占用的性能(内存，CPU 等)
5. Swarm 集群管理：可以管理 swarm 集群，是最大的优点
6. 登录用户管理：有完备的用户系统，权限控制

## Protainer 缺点：

1. Portainer 没有自带的高可用。
2. Portainer 没有中文页面，官方没有提供中文翻译。

## 使用官方的 Demo 预览一下（从预览到放弃？速度很慢。）

地址： [http://demo.portainer.io/](http://demo.portainer.io/)
用户名： admin
密码： tryportainer

*为了方便安装，我们先配置 docker 加速镜像。<p style="color:red;">*

*以下方法适用 docker 版本大于 1.10.0。</p>*

## 1.选用阿里云镜像服务给 docker 镜像加速

登录[阿里云镜像加速器](https://cr.console.aliyun.com/cn-hangzhou/instances/mirrors)服务页面（需要登录阿里云账号）
获取阿里云专属加速器地址，如下图：
![image.png](https://img.hacpai.com/file/2019/12/image-95b15060.png)
以 CentOS 系统为例：
可以通过修改 daemon 配置文件/etc/docker/daemon.json 来使用加速器

```shell
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://xxxxxx.mirror.aliyuncs.com"]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```

其他系统在页面又有对应教程，参考设置即可。

## 2.配置启动 portainer

```shell
docker run -d -p 9000:9000 -v /var/run/docker.sock:/var/run/docker.sock portainer/portainer
```

### 命令说明

* docker run： 创建一个容器
* -d：后台运行容器，并返回容器 ID；
* -p 9000:9000：指定端口映射，格式为：主机(宿主)端口：容器端口
* -v /var/run/docker.sock:/var/run/docker.sock： 绑定一个文件或目录到容器，格式为：主机(宿主)文件：容器文件
* portainer/portainer： 待运行的镜像名称，如果本队不存在，或自动从 docker hub 上下载

## 3.使用

访问 http://ip:9000
![image.png](https://img.hacpai.com/file/2019/12/image-7dab319c.png)
首次登录的时候会让你创建一个管理员账号。
![image.png](https://img.hacpai.com/file/2019/12/image-d1790e09.png)
配置本地还是远程主机，这里我们选择 Local 选项本地主机。
![image.png](https://img.hacpai.com/file/2019/12/image-d04ea4af.png)
点击 local 进入当前主机的 Dashboard
![image.png](https://img.hacpai.com/file/2019/12/image-2e8398e7.png)
如图显示当前主机硬件资源和容器运行情况，当前 0 个堆阀数（Stacks），运行了 15 个容器（Containers）15 个存活 0 个停止、总共有 15 个镜像（Images） 、3 个挂载卷和 4 个网络设置。
右侧菜单分别为：

* App Templates：App 的模板，内置 40 多个常用的服务模板，可以去更新这些，也可以删除。点击新建可以创建适合自己环境的模板，方便快速部署自己的服务。
* Stacks：这里是制作自己的 docker compose 里的文件，可以创建自己的 docker compose 快速部署
* Containers：管理的主机或者及集群的所有容器，点击需要管理的容器可以查看容器详细信息。进入详情也厚有对应的运维操作：Logs(查看日志)，inspect(相当于 docker inspect，查看容器详细信息)，Stats(查看容器占据的性能信息，包括占用的内存 CPU 等信息)，Console(进入 docker 容器，相当于 exec)，Attach(docker attach，不建议使用，也不好用)
* Images：镜像操作，可以通过页面进行 pull 操作，可以查看机器上的所有镜像的详细信息，可进行大部分镜像操作(删除，build，import 导入)
* Network：展现的是机器或者集群上 network 信息，在多机器 docker 维护中，经常需要创建维护 docker network。
* Volume：Volume 就是机器上的数据卷信息，提供创建删除查看的操作。

````以上就是

````