title: 如何配置MAVEN私有远程仓库
date: '2019-12-09 13:13:45'
updated: '2019-12-09 13:13:45'
tags: [java, maven]
permalink: /articles/2019/12/09/1575897225619.html
---
# 如何配置MAVEN私有远程仓库
---
*修改 MAVEN 私有仓库分三种：*

*1. 修改项目的 pom.xml，只对本项目起效；
2. 修改 $MAVEN_HOME/conf/下的 setting.xml 文件；*

## 1. 针对本项目起效，修改 pom.xml 文件。

以阿里云仓库为例，直接在项目的 pom.xml 中修改中央库的地址。如下：

```xml
<repositories>
    <repository>
        <id>alimaven</id>
        <name>aliyun maven</name>
        <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
    </repository>
</repositories>
```

## 2. 修改 $MAVEN_HOME/conf/下的 setting.xml 文件。

可以直接修改 Maven 目录下 conf 文件夹中的 setting.xml 文件，或者在.m2 文件夹下建立一个 setting·XML 文件。

setting.xml 里面有个 mirrors 节点，用来配置镜像 URL。mirrors 可以配置多个 mirror，每个 mirror 有 id,name,url,mirrorOf 属性。

* id 是唯一标识一个 mirror
* name 貌似没多大用，相当于描述
* url 是官方的库地址
* mirrorOf 代表了一个镜像的替代位置，例如 central 就表示代替官方的中央库，*代表替换所有库。

mirror 也不是按 settings.xml 中写的那样的顺序来查询的。所谓的第一个并不一定是最上面的那个。

当有 id 为 B,A,C 的顺序的 mirror 在 mirrors 节点中，maven 会根据字母排序来指定第一个，所以不管怎么排列，一定会找到 A 这个 mirror 来进行查找，当 A 无法连接，出现意外的情况下，才会去 B 查询。

```xml
<mirrors>  
    ...   
    <mirror>  
      <id>alimaven</id>  
      <name>aliyun maven</name>  
      <url>http://maven.aliyun.com/nexus/content/groups/public/</url>  
      <mirrorOf>central</mirrorOf>          
    </mirror>
</mirrors>
```