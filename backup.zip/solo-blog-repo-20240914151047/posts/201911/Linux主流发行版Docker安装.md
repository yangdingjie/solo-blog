title: Linux主流发行版Docker安装
date: '2019-11-23 10:45:10'
updated: '2019-11-23 10:45:10'
tags: [docker, linux, 安装]
permalink: /articles/2019/11/23/1574505910249.html
---
# Linux 主流发行版 Docker 安装

---
> ## 1. 卸载旧版 Docker
>
> > ### 1.1 CentOS 卸载
> >
> > ```shell
> > $ sudo yum remove docker \  
> >               docker-client \  
> >               docker-client-latest \  
> >               docker-common \  
> >               docker-latest \  
> >               docker-latest-logrotate \  
> >               docker-logrotate \  
> >               docker-engine
> > ```
> >
> > ### 1.2 Ubuntu 以及 Debian 卸载
> >
> > ```shell
> > $ sudo apt-get remove docker docker-engine docker.io containerd runc
> > ```
> >
>
> ## 2. 安装 Docker 软件仓库
>
> 在新主机上首次安装 Docker Engine-Community 之前，需要设置 Docker 仓库。之后，您可以从仓库安装和更新 Docker。
>
> > ### 2.1 CentOS 安装软件源
> >
> > ### 设置软件源
> >
> > *安装所需的软件包。yum-utils 提供了 yum-config-manager ，并且 device mapper 存储驱动程序需要 device-mapper-persistent-data 和 lvm2。*
> >
> > ```shell
> > $ sudo yum install -y yum-utils \  
> >  	      device-mapper-persistent-data \  
> >  	       lvm2
> > ```
> >
> > 使用以下命令来设置稳定的软件源。
> >
> > ```shell
> > $ sudo yum-config-manager \  
> >               --add-repo \
> >               https://download.docker.com/linux/centos/docker-ce.repo
> > ```
> >
> > ### 2.2 Ubuntu 以及 Debian 安装软件源
> >
> > ### 设置软件源
> >
> > ### 更新 apt 包索引。
> >
> > ```shell
> > $ sudo apt-get update
> > ```
> >
> > ### 安装 apt 依赖包，用于通过 HTTPS 来获取软件源:
> >
> > ```shell
> > $ sudo apt-get install \  
> >               apt-transport-https \  
> >               ca-certificates \  
> >               curl \  
> >               gnupg-agent \  
> >               software-properties-common  
> > ```
> >
> > ### 添加 Docker 的官方 GPG 密钥：
> >
> > ```shell
> > $ curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
> > ```
> >
> > *9DC8 5822 9FC7 DD38 854A E2D8 8D81 803C 0EBF CD88 通过搜索指纹的后 8 个字符，验证您现在 &gt;&gt; 是否拥有带有指纹的密钥。*
> >
> > ```
> > $ sudo apt-key fingerprint 0EBFCD88     
> >
> > pub   rsa4096 2017-02-22 [SCEA]  
> >      9DC8 5822 9FC7 DD38 854A  E2D8 8D81 803C 0EBF CD88  
> > uid           [ unknown] Docker Release (CE deb) <docker@docker.com>  
> > sub   rsa4096 2017-02-22 [S]  
> > ```
> >
> > ### 使用以下指令设置稳定版软件源
> >
> > ```shell
> > $ sudo add-apt-repository \  
> >               "deb [arch=amd64] https://download.docker.com/linux/ubuntu \  
> >               $(lsb_release -cs) \  
> >               stable"
> > ```
> >
> > 更新 apt 包索引。
> >
> > ```shell
> > $ sudo apt-get update
> > ```
> >
>
> ## 3. 安装 Docker Engine-Community
>
> *安装最新版本的 Docker Engine-Community 和 containerd*
>
> > ### 3.1 CentOS 安装
> >
> > ```shell
> > $ sudo yum install docker-ce docker-ce-cli containerd.io
> > ```
> >
> > + *如果提示您接受 GPG 密钥，请选是。*
> >
> > ### 3.2 Ubuntu 以及 Debian 安装
> >
> > ```shell
> > $ sudo apt-get install docker-ce docker-ce-cli containerd.io
> > ```
> >
> > ## 4. 验证安装成果
> >
> > ### 启动 Docker。
> >
> > ```shell
> > $ sudo systemctl start docker
> > ```
> >
> > ### 测试 Docker 是否安装成功，输入以下指令，打印出以下信息则安装成功:
> >
> > ```shell
> > $ sudo docker run hello-world  
> >
> > Unable to find image 'hello-world:latest' locally  
> > latest: Pulling from library/hello-world  
> > 1b930d010525: Pull complete                                                                                                                                 Digest: sha256:c3b4ada4687bbaa170745b3e4dd8ac3f194ca95b2d0518b417fb47e5879d9b5f  
> > Status: Downloaded newer image for hello-world:latest  
> >  
> >  
> > Hello from Docker!  
> > This message shows that your installation appears to be working correctly.  
> >  
> >  
> > To generate this message, Docker took the following steps:  
> > 1. The Docker client contacted the Docker daemon.  
> > 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.  
> >   (amd64)  
> > 3. The Docker daemon created a new container from that image which runs the  
> >    executable that produces the output you are currently reading.  
> > 4. The Docker daemon streamed that output to the Docker client, which sent it  
> >    to your terminal.  
> >  
> >  
> > To try something more ambitious, you can run an Ubuntu container with:  
> > ```
> >
> > ### 开机启动
> >
> > ```shell
> > $ sudo systemctl enable docker
> > ```
> >
> > ### 禁用开机启动
> >
> > ```shell
> > $ sudo systemctl disable docker
> > ```
> >