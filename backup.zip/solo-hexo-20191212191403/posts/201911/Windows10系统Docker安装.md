title: Windows 10 系统 Docker 安装
date: '2019-11-24 22:09:54'
updated: '2019-11-24 22:18:44'
tags: [docker, windows, 安装]
permalink: /articles/2019/11/24/1574604593908.html
---
# Windows 10 系统 Docker 安装

---
> ## 1. 开启 Hyper-V
>
> *Docker 有专门的 Win10 专业版系统的安装包，需要开启 Hyper-V。*
>
> > ![blog_win10_docker_1](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_1.png)
> > 程序和功能
> > ![blog_win10_docker_2](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_2.png)
> > 启用或关闭 Windows 功能
> >
> > ![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_3.png)
> >
> > 选中 Hyper-V
> >
> > ![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_4.png)
> >
>
> ## 2、安装 Toolbox
>
> > *最新版 Toolbox 下载地址： [https://www.docker.com/get-docker](https://www.docker.com/get-%3Edocker)*
> >
> > *点击 [Download Desktop and Take a Tutorial](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_5.png)，并下载 Windows 的版本，如果你还没有登录，会要求注册登录：*
> >
> > ![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_5.png)
> >
> > ![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_6.png)
> >
> > ![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_7.png)
> >
>
> ## 3、运行安装文件
>
> > 双击下载的 Docker for Windows Installer 安装文件，一路 Next，点击 Finish 完成安装。
> >
> > ![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_8.png)
> >
> > ![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_9.png)
> >
> > 安装完成后，Docker 会自动启动。通知栏上会出现个小鲸鱼的图标![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_10.png)，这表示 Docker 正在运行。
> >
> > 桌边也会出现三个图标，入下图所示：
> >
> > 我们可以在命令行执行 docker version 来查看版本号，docker run hello-world 来载入测试镜像测试。
> >
> > 如果没启动，你可以在 Windows 搜索 Docker 来启动：
> >
> > ![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_11.png)
> >
> > 启动后，也可以在通知栏上看到小鲸鱼图标：
> >
> > ![null](https://git.yangdj.cn/yangdingjie/static-images/raw/branch/master/blog/blog_win10_docker_12.png)
> >
